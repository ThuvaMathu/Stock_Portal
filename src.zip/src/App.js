import './App.css';
import * as React from 'react';
import Navbar from './components/navbar/navbar';




function App() {

  return (
    <div className='main'>

        <Navbar />
        
        
    </div>
  );
}

export default App;

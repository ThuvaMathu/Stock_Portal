import React, { useEffect, useState } from 'react';



export default function Companypro() {
 console.log("profile")

    // const [loading, setLoading] = useState(true);
    // const [show, setShow] = useState(false);
    // const [profile, setProfile] = useState();

    // const API_KEY = 'f09e040716cb0920a7927288d97a5067A'

    // async function getdata() {
    //     const { Symbol } = props.match.params;
    //     let url = `https://financialmodelingprep.com/api/v3/profile/${Symbol}?apikey=YOUR_API_KEY=${API_KEY}`
    //     let res = await fetch(url);
    //     let data = await res.json();
    //     setProfile(data)
    //     if (data.length > 0) { setLoading(false) }
    //     console.log(data.length, "length")
    // }

    // useEffect(() => {
    //     console.log("hello")
    //     getdata();

    // }, []);


    return (
        <div style={{marginTop:'100px'}}>
            <h1> Hello renterderd world </h1>
            <h1> Hello renterderd world </h1>
            <h1> Hello renterderd world </h1>
            <h1> Hello renterderd world </h1>
            <h1> Hello renterderd world </h1>
            <h1> Hello renterderd world </h1>
            <h1> Hello renterderd world </h1>
            <h1> Hello renterderd world </h1>
        </div>
    );
}
